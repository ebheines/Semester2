Requirements to run the program:
    - Python installed on the computer
        link: https://www.python.org/downloads/ 
    - Pygame library installed
        link: https://www.pygame.org/download.shtml 

Running the program:
    Use the "python" or "python3" compiler to run the progam and run the "main.py" file to see the boids implementation. 