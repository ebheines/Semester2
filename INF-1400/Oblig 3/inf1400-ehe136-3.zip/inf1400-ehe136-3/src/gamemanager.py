import pygame
from spaceship import SpaceShip
from landingpad import LandingPad
from obstacle import Obstacle
from bullet import Bullet
from config import Config

"""
Module: Landingpad
Author: Kristian Harvey Olsen, Eskil Bjørnbakk Heines
"""

window = Config.window
font = Config.font

pygame.init()


class GameManager:
    """
    Main class for running the game, making the methods for the main file
    """
    def __init__(self):
        self.player1Spaceship = SpaceShip(
            window, Config.ImageSpaceship1, Config.Controls_Arrows, Config.Player1_Position)
        self.player2Spaceship = SpaceShip(
            window, Config.ImageSpaceship2, Config.Controls_WASD, Config.Player2_Position)

        self.spaceships = [self.player1Spaceship, self.player2Spaceship]
        self.spaceShipGroup = pygame.sprite.Group()
        for spaceship in self.spaceships:
            self.spaceShipGroup.add(spaceship)

        self.landingPad1 = LandingPad(Config.LandingPad1_Position)
        self.landingPad2 = LandingPad(Config.LandingPad2_Position)

        self.startScreenImage = pygame.transform.scale(pygame.image.load(
            Config.start_screen), (Config.screenWidth, Config.screenHeight))

        self.landingPads = [self.landingPad1, self.landingPad2]
        self.landingPadGroup = pygame.sprite.Group()
        for pad in self.landingPads:
            self.landingPadGroup.add(pad)

        self.obstacles = []
        self.obstacle = Obstacle(window, Config.StoneImage)
        self.obstacles.append(self.obstacle)
        self.obstacleCooldown = 0
        self.obstacleGroup = pygame.sprite.Group()
        self.obstacleGroup.add(self.obstacle)

    def startLoop(self):
        """
        Method for running the start screen of the game
        """
        running = True
        while running:
            window.blit(self.startScreenImage, (0, 0))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_RETURN:
                        self.gameLoop()
                    if event.key == pygame.K_ESCAPE:
                        running = False
            pygame.display.update()
        pygame.quit()

    def gameLoop(self):
        """
        Method for running the actual game
        """
        clock = pygame.time.Clock()
        running = True
        while running:
            window.fill((0, 0, 0))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False

            clock.tick(30)
            keys = pygame.key.get_pressed()

            self.update(keys)
            self.displayValues()

            pygame.display.update()
        pygame.quit()

    def playerControls(self, spaceship: SpaceShip, keys: pygame.key.get_pressed):
        """
        Method for the controls of the spaceship
        """
        if keys[spaceship.controls["Thrust"]]:
            if spaceship.fuel > 0:
                spaceship.thrust()
                spaceship.fuel -= Config.FuelReduction

        if keys[spaceship.controls["Left"]]:
            spaceship.rotate(1)
        elif keys[spaceship.controls["Right"]]:
            spaceship.rotate(-1)

        if keys[spaceship.controls["Fire"]]:
            spaceship.shoot()
            Config.fire_sound.play()

    def spaceshipLandOnPad(self):
        """
        Method for fueling and stopping the spaceship when it lands on the landing pad
        """
        for spaceship in self.spaceships:
            spaceship_near_platform = pygame.sprite.spritecollide(
                spaceship, self.landingPadGroup, False)

            if spaceship_near_platform:
                spaceship.velocity = pygame.Vector2(0, 0)
                spaceship.on_landingPad = True
                spaceship.fueling = True

            if spaceship.fueling and spaceship.fuel < Config.MaxFuel:
                spaceship.fuel += 2
                if spaceship.fuel > Config.MaxFuel:
                    spaceship.fuel = Config.MaxFuel
                elif spaceship.fuel < 0:
                    spaceship.fuel = 0
                spaceship.fueling = False

    def spaceshipHitByBullet(self):
        """
        Method for when a spaceship is hit by a bullet, adding score and resetting the spaceship that's hit
        """
        player1_collide = pygame.sprite.spritecollide(
            self.player1Spaceship, self.player2Spaceship.bullets, True)
        player2_collide = pygame.sprite.spritecollide(
            self.player2Spaceship, self.player1Spaceship.bullets, True)

        if player1_collide and not self.player1Spaceship.fueling:
            self.player1Spaceship.reset()
            self.player2Spaceship.score += 1
        if player2_collide and not self.player2Spaceship.fueling:
            self.player2Spaceship.reset()
            self.player1Spaceship.score += 1

        clock = pygame.time.Clock()

        if self.player1Spaceship.rect.colliderect(self.player2Spaceship.rect):
            self.player1Spaceship.reset()
            self.player1Spaceship.score -= 1
            self.player2Spaceship.reset()
            self.player2Spaceship.score -= 1

    def bulletHitObstacle(self):
        """
        Method for destroying an obstacle when it's shot at
        """
        for obstacle in self.obstacles:
            player1_bullet_collision = pygame.sprite.spritecollide(
                obstacle, self.player1Spaceship.bullets, False)
            player2_bullet_collision = pygame.sprite.spritecollide(
                obstacle, self.player2Spaceship.bullets, False)

            if player1_bullet_collision:
                self.obstacleGroup.remove(obstacle)
            if player2_bullet_collision:
                self.obstacleGroup.remove(obstacle)

    def spaceshipCollideObstacle(self):
        """
        Method for collision between spaceships and obstacles
        """
        player1_collision = pygame.sprite.spritecollide(
            self.player1Spaceship, self.obstacleGroup, True)
        player2_collision = pygame.sprite.spritecollide(
            self.player2Spaceship, self.obstacleGroup, True)
        if player1_collision:
            self.player1Spaceship.reset()
            self.player1Spaceship.score -= 1
        if player2_collision:
            self.player1Spaceship.reset()
            self.player2Spaceship.score -= 1

    def spawnObstacle(self):
        """
        Method for spawning obstacles on the screen
        """
        if self.obstacleCooldown > 0:
            self.obstacleCooldown -= 1
        if self.obstacleCooldown == 0:
            self.obstacleCooldown = 60
            obstacle = Obstacle(window, Config.StoneImage)
            self.obstacles.append(obstacle)
            self.obstacleGroup.add(obstacle)

    def displayScore(self):
        """
        Method for displaying the score of each player
        """
        player1_score_position = (1450, 825)
        font1 = font.render("Score: {}".format(
            self.player1Spaceship.score), False, (255, 255, 255))
        window.blit(font1, player1_score_position)
        player2_score_position = (10, 825)
        font2 = font.render("Score: {}".format(
            self.player2Spaceship.score), False, (255, 255, 255))

        window.blit(font1, player1_score_position)
        window.blit(font2, player2_score_position)

    def fuelBar(self):
        """
        Method for displaying the fuel-level of each player
        """
        fuel_bar_length = 200
        fuel_bar_ratio = Config.MaxFuel / fuel_bar_length

        pygame.draw.rect(window, (208, 0, 0), (10, 865, fuel_bar_length, 25))
        pygame.draw.rect(window, (0, 0, 208),
                         (10, 865, self.player2Spaceship.fuel / fuel_bar_ratio, 25))
        pygame.draw.rect(window, (125, 125, 125),
                         (10, 865, fuel_bar_length, 25), 2)

        pygame.draw.rect(window, (208, 0, 0), (1390, 865, fuel_bar_length, 25))
        pygame.draw.rect(window, (0, 0, 208),
                         (1390, 865, self.player1Spaceship.fuel / fuel_bar_ratio, 25))
        pygame.draw.rect(window, (125, 125, 125),
                         (1390, 865, fuel_bar_length, 25), 2)

    def update(self, keys):
        """
        Method for updating the program; calling for all the others methods for the program
        """
        for spaceship in self.spaceships:
            self.playerControls(spaceship, keys)

        self.spaceshipLandOnPad()
        self.spaceshipHitByBullet()
        #self.spaceshipCollision()
        self.bulletHitObstacle()
        self.spaceshipCollideObstacle()
        self.spawnObstacle()
        self.spaceshipCollideObstacle()

        self.spaceShipGroup.draw(window)
        self.spaceShipGroup.update()

        self.landingPadGroup.draw(window)
        self.landingPadGroup.update()

        self.player1Spaceship.bullets.draw(window)
        self.player1Spaceship.bullets.update()
        self.player2Spaceship.bullets.draw(window)
        self.player2Spaceship.bullets.update()

        self.obstacleGroup.draw(window)
        self.obstacleGroup.update()

    def displayValues(self):
        """
        Method for displaying the score and fuel
        """
        self.displayScore()
        self.fuelBar()
