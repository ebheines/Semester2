import pygame
import math
import random


class Config:
    pygame.init()
    pygame.font.init()

    # Screen, pygame window and font
    ###############################################
    screenWidth = 1600
    screenHeight = 900
    window = pygame.display.set_mode((screenWidth, screenHeight), 0)
    pygame.display.set_caption("Mayham")
    font = pygame.sysfont.SysFont('dejavuserif', 30)
    fire_sound = pygame.mixer.Sound('assets/fire.wav')
    fire_sound.set_volume(0.2)
    thrust_sound = pygame.mixer.Sound('assets/thrust.wav')
    thrust_sound.set_volume(0.2)
    start_screen = "assets/startscreen.jpg"
    ###############################################

    # Spaceship
    ###############################################
    ImageSpaceship1 = "assets/spaceship1.png"
    ImageSpaceship1_thrust = "assets/spaceship1_thrust.png"
    Player1_Position = pygame.Vector2(1300, 170)
    ImageSpaceship2 = "assets/spaceship2.png"
    ImageSpaceship2_thrust = "assets/spaceship2_thrust.png"
    Player2_Position = pygame.Vector2(300, 670)

    thrustImage = "assets/flame.webp"
    thrustImageMaxSize_x = 30
    thrustImageMaxSize_y = 60

    SpaceshipSize = 50
    SpaceshipSpeed = pygame.Vector2()
    MaxFuel = 300
    FuelReduction = 1
    Thrust_force = 1
    Spaceship_rotation_speed = 10
    Spaceship_max_speed = 4
    Gravity = pygame.Vector2(0, 0.2)
    StartAngle = 0
    ###############################################

    # Bullet
    ###############################################
    Radius = 2
    BulletSpeed = 25
    BulletColor = (255, 255, 255)
    ###############################################

    PlatformImage = "assets/platform.png"
    LandingPadSize_x = 100
    LandingPadSize_y = 20

    LandingPad1_Position = (1300, 200)
    LandingPad2_Position = (300, 700)
    ###############################################

    # Obstacle

    StoneImage = "assets/stone.png"
    StoneSize = 50
    StoneAngle = 0
    StoneSpeed = 3
    Stone_rotation_speed = 10

    # Player controls
    ###############################################
    Controls_Arrows = {
        "Thrust": pygame.K_UP,
        "Left": pygame.K_LEFT,
        "Right": pygame.K_RIGHT,
        "Fire": pygame.K_RSHIFT
    }
    Controls_WASD = {
        "Thrust": pygame.K_w,
        "Left": pygame.K_a,
        "Right": pygame.K_d,
        "Fire": pygame.K_SPACE
    }
    ###############################################
