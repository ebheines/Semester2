import pygame
from config import Config


class LandingPad(pygame.sprite.Sprite):
    def __init__(self, position):
        super().__init__()
        """
        Class for the landing pads
        """
        self.image = pygame.transform.scale(pygame.image.load(
            Config.PlatformImage), (Config.LandingPadSize_x, Config.LandingPadSize_y))
        self.position = position

        self.rect = self.image.get_rect()
        self.rect.center = self.position
