from gamemanager import GameManager
import cProfile
import pstats
from pstats import SortKey

if __name__ == "__main__":
    cProfile.run('GameManager', "output.dat")
    game = GameManager()
    game.startLoop()

    with open("output_time.txt", "w") as file:
        p = pstats.Stats("output.dat", stream=file)
        p.sort_stats("time").print_stats()

    with open("output_calls.txt", "w") as file:
        p = pstats.Stats("output.dat", stream=file)
        p.sort_stats("calls").print_stats()
