import pygame
from config import Config

"""
Module: Bullet
Author: Kristian Harvey Olsen, Eskil Bjørnbakk Heines
"""


class Bullet(pygame.sprite.Sprite):
    """
    Bullet object, draws a circle at the position and direction from arguments. Moves with a constanst velocity.
    """

    def __init__(self, position, direction):
        super().__init__()
        self.position = position
        self.direction = direction.normalize()
        self.radius = Config.Radius
        self.velocity = pygame.Vector2(0, 0)
        self.color = Config.BulletColor
        self.speed = Config.BulletSpeed

        self.image = pygame.Surface(
            (self.radius * 2, self.radius * 2), pygame.SRCALPHA)

        pygame.draw.circle(self.image, self.color,
                           (self.radius, self.radius), self.radius)

        self.rect = self.image.get_rect()
        self.rect.center = self.position

    def update(self):
        """
        Updating position and object center each frame
        """
        self.position += self.velocity
        self.rect.center = self.position

    def wallCollision(self):
        """
        Checks for out of screen edges, so the bullets get deleted once it is out of frame
        """
        if self.position.x + self.radius > Config.screenWidth:
            self.kill()
        elif self.position.x - self.radius < 0:
            self.kill()
        elif self.position.y + self.radius > Config.screenHeight:
            self.kill()
        elif self.position.y - self.radius < 0:
            self.kill()
