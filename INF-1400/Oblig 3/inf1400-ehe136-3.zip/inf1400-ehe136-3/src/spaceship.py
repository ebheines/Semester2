import pygame
import math
from config import Config
from landingpad import LandingPad
from bullet import Bullet


class SpaceShip(pygame.sprite.Sprite):
    def __init__(self, window: pygame.Surface, image, controls, start_position: pygame.Vector2):
        super().__init__()
        self.window = window

        self.image = pygame.transform.scale(
            pygame.image.load(image), (Config.SpaceshipSize, Config.SpaceshipSize)).convert_alpha()
        self.originalImage = self.image

        # self.thrustImage = pygame.image.load(Config.thrustImage)
        self.thrustImage = pygame.transform.scale(pygame.image.load(
            Config.thrustImage), (Config.thrustImageMaxSize_x, Config.thrustImageMaxSize_y)).convert_alpha()
        self.thrustImage = pygame.transform.rotate(self.thrustImage, 180)
        self.thrustImageOriginal = self.thrustImage

        self.controls = controls
        self.gravity = Config.Gravity
        self.angle = Config.StartAngle
        self.fuel = Config.MaxFuel
        self.fueling = False
        self.position = start_position
        self.startPosition = start_position.copy()
        self.velocity = pygame.Vector2(0, 0)
        self.bullets = pygame.sprite.Group()
        self.bullet_cooldown = 0
        self.direction = pygame.Vector2(0, -1)
        self.score = 0

        self.on_landingPad = False

        self.rect = self.image.get_rect()
        self.rect.center = self.position

        self.thrustrect = self.thrustImage.get_rect()
        self.thrustrect.center = self.position

    def shoot(self):
        bullet_position = self.position.copy()
        bullet_direction = pygame.Vector2(0, -1).rotate(self.angle)
        if self.bullet_cooldown > 0:
            self.bullet_cooldown -= 1
        if not self.fueling and self.bullet_cooldown == 0:
            self.bullet_cooldown = 5
            bullet = Bullet(bullet_position, bullet_direction)
            bullet.velocity = bullet_direction * bullet.speed
            self.bullets.add(bullet)

    def rotateImage(self):
        self.image = pygame.transform.rotate(self.originalImage, -self.angle)
        self.rect = self.image.get_rect(center=self.position)

    def rotateThrustImage(self):
        self.thrustImage = pygame.transform.rotate(
            self.thrustImageOriginal, -self.angle)
        self.thrustrect = self.thrustImage.get_rect(center=self.position)

    def rotate(self, direction):
        if direction > 0:
            self.angle -= Config.Spaceship_rotation_speed
            self.direction.rotate_ip(self.angle)
            self.rotateImage()
        if direction < 0:
            self.angle += Config.Spaceship_rotation_speed
            self.direction.rotate_ip(self.angle)
            self.rotateImage()

    def clamp_force(self, vector, force):
        length = vector.length()

        if length > force:
            multiplier = force / length
        else:
            multiplier = force
        vector *= multiplier

    def thrust(self):
        self.velocity -= pygame.Vector2(0,
                                        Config.Thrust_force).rotate(self.angle)

        if self.velocity.length() > Config.Spaceship_max_speed:
            self.velocity.scale_to_length(Config.Spaceship_max_speed)

        self.position += self.velocity

        thrust_scale_factor = self.velocity.length() / Config.Thrust_force
        self.thrustImage = pygame.transform.scale(
            self.thrustImage, (5,
                               thrust_scale_factor)).convert_alpha()

        thrust_offset = pygame.Vector2(
            0, self.rect.height / 2).rotate(self.angle)
        thrust_position = self.position.copy()
        self.thrustrect.center = thrust_position + thrust_offset
        self.thrustImage = pygame.transform.rotate(
            self.thrustImageOriginal, -self.angle)
        # self.rotateThrustImage()
        self.window.blit(self.thrustImage, self.thrustrect)


    def wall_collision(self):
        if self.position.x > self.window.get_width():
            self.reset()
        elif self.position.x < 0:
            self.reset()
        elif self.position.y > self.window.get_height():
            self.reset()
        elif self.position.y < 0:
            self.reset()

    def update(self):
        self.velocity += self.gravity
        self.position += self.velocity
        self.rect.center = self.position
        self.thrustrect.center = self.position
        self.rotateImage()
        self.wall_collision()

        if self.on_landingPad:
            self.gravity = pygame.Vector2(0, 0)
            self.on_landingPad = False
        else:
            self.gravity = Config.Gravity

    def reset(self):
        self.position = self.startPosition.rotate(self.angle)
        self.velocity = pygame.Vector2(0, 0)
        self.angle = Config.StartAngle
        self.fuel = Config.MaxFuel
