import pygame
import random
from config import Config

"""
Module: Obstacle
Author: Kristian Harvey Olsen, Eskil Bjørnbakk Heines
"""


class Obstacle(pygame.sprite.Sprite):
    """
    Class for the obstacles in the game
    """
    def __init__(self, window, image):
        super().__init__()
        self.window = window

        self.image = pygame.transform.scale(pygame.image.load(
            image), (Config.StoneSize, Config.StoneSize)).convert_alpha()
        self.originalImage = self.image

        self.position = pygame.Vector2(
            random.randint(0, 300), random.randint(0, 100))

        self.velocity = pygame.Vector2(0, 0)

        self.angle = 0
        self.angleUpdate = 0

        self.rect = self.image.get_rect()
        self.rect.center = self.position

    def _rotateImage(self):
        """
        Method for rotating the image
        """
        self.image = pygame.transform.rotate(self.originalImage, -self.angle)
        self.rect = self.image.get_rect(center=self.position)

    def rotate(self):
        """
        Method for rotating the actual object
        """
        self.angle += 5
        self._rotateImage()

    def move(self):
        """
        Method for moving the obstacle
        """
        self.velocity += pygame.Vector2(random.randint(1, 4),
                                        2) + Config.Gravity
        self.position += self.velocity

    def update(self):
        """
        Method for updating the obstacle
        """
        self.move()
        self.rotate()
        self.velocity *= 0
        self.rect.center = self.position
