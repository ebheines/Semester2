/* Author: Steffen Viken Valvaag <steffenv@cs.uit.no> */
#include "common.h"
#include "list.h"
#include "map.h"

int main(int argc, char **argv)
{
    return 0;
}
